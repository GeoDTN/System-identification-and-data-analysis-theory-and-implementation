% Example: amplitude and phase of a sinusoid

F = 2;
omega = 2*pi*F;

Y   = [ 0.294; 1.358; 2.382; 0.840; 0.864; 0.310; 1.000; 2.148; 1.821; 1.104 ];
T   = [ 1.636; 2.602; 3.527; 4.614; 5.368; 6.636; 7.425; 8.073; 8.578; 9.432 ];
Phi = [sin(omega*T), cos(omega*T)];

thetaLS = pinv(Phi)*Y;
Ahat    = sqrt(thetaLS(1)^2 + thetaLS(2)^2)
phihat  = atan2(thetaLS(2), thetaLS(1))

