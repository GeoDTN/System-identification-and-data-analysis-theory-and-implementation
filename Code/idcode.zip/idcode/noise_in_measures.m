% Model: y(i+1) = a y(i) + b u(i)
% u(i) is measured without errors
% y(i) is measured with an error, ym(i) = y(i) + e(i)
 
nruns = 100;   % Number of identification experiments
a_estimates = zeros(1, nruns);
b_estimates = zeros(1, nruns);

for run=1:nruns,
   % Construction of the process
   N = 1000;                   % Time horizon
   a = 0.8;                    % Parameter
   b = 0.2;                    % Parameter
   u = randn(N,1);             % Some input signal
   e = 0.3*randn(N+1,1);       % Some random noise

   y = zeros(N+1, 1);
   y(1) = 4;                   % Initial condition
   for i=1:N,
      y(i+1) = a*y(i) + b*u(i);
   end
   ym = y + e;                 % Measured output

   % Data for least squares
   ypast    = ym(1:N);
   ypresent = ym(2:N+1);
   Phi = [ypast, u];           % Regressors

   % Least squares estimation
   theta_LS = pinv(Phi)*ypresent;
	a_estimates(run) = theta_LS(1);
	b_estimates(run) = theta_LS(2);
end

disp(sprintf('Average LS estimate of a over %d runs: %7.5f', nruns, mean(a_estimates)));
disp(sprintf('Average LS estimate of b over %d runs: %7.5f', nruns, mean(b_estimates)));

